// background.js

chrome.action.onClicked.addListener((tab) => {
  // Send a message to all frames in the active tab to activate the picker.
  chrome.tabs.sendMessage(tab.id, { type: 'activatePicker' });
});

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Check if the message is of type 'saveFilter'
    if (request.type === 'saveFilter') {
        const newFilter = request.filter;
        if (!newFilter) {
            console.error('Received an empty filter to save.');
            return;
        }
        chrome.storage.local.get({ userFilters: [] }, (data) => {
            const filters = data.userFilters;
            if (!filters.includes(newFilter)) {
                filters.push(newFilter);
            }
            chrome.storage.local.set({ userFilters: filters }, () => {
                console.log('Filter saved successfully:', newFilter);
            });
        });
        return; // End here if this was the message
    }
    
    // Handling saving and reading colors
    if (request.type === 'getColors') {
        chrome.storage.sync.get(['hoverColor', 'selectionColor'], (data) => {
            sendResponse({
                hoverColor: data.hoverColor,
                selectionColor: data.selectionColor
            });
        });
        // Return true to indicate that the response will be sent asynchronously
        return true; 
    }
    
    if (request.type === 'saveHoverColor') {
        chrome.storage.sync.set({ hoverColor: request.color });
    }
    
    if (request.type === 'saveSelectionColor') {
        chrome.storage.sync.set({ selectionColor: request.color });
    }
});