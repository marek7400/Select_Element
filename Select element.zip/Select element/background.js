chrome.action.onClicked.addListener((tab) => {
  // Wstrzyknij style CSS do aktywnej karty
  chrome.scripting.insertCSS({
    target: { tabId: tab.id },
    files: ["picker.css"]
  });

  // Wstrzyknij i wykonaj skrypt contentowy
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["picker.js"]
  });
});

// Nasłuchuj wiadomości od skryptów contentowych (np. picker.js)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Sprawdź, czy wiadomość jest typu 'saveFilter'
    if (request.type === 'saveFilter') {
        const newFilter = request.filter;
        if (!newFilter) {
            console.error('Otrzymano pusty filtr do zapisu.');
            return;
        }

        // Pobierz istniejące filtry z chrome.storage.local
        chrome.storage.local.get({ userFilters: [] }, (data) => {
            const filters = data.userFilters;

            // Dodaj nowy filtr tylko jeśli jeszcze nie istnieje, aby uniknąć duplikatów
            if (!filters.includes(newFilter)) {
                filters.push(newFilter);
            }

            // Zapisz zaktualizowaną listę filtrów
            chrome.storage.local.set({ userFilters: filters }, () => {
                console.log('Filtr zapisany pomyślnie:', newFilter);
                console.log('Aktualna lista filtrów:', filters);
            });
        });
    }
});