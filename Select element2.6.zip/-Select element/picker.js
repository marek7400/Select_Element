// picker.js

// --- Global variables and listeners ---
const isTopFrame = window === window.top;
const MESSAGE_PREFIX = 'ubo-picker-msg::';
let activeFrames = []; // Used only in top-frame

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'activatePicker') {
    initialize();
  }
});

let currentSelector = '';
let currentMode = 'similar';
let highlightedElementForCopy = null;

window.addEventListener('message', (event) => {
    if (event.source === window || !event.data || typeof event.data.type !== 'string' || !event.data.type.startsWith(MESSAGE_PREFIX)) {
        return;
    }
    const { type, payload } = event.data;

    if (isTopFrame && window.elementPickerInstance) {
        switch (type) {
            case `${MESSAGE_PREFIX}frame-ready`:
                if (!activeFrames.includes(event.source)) activeFrames.push(event.source);
                break;
            case `${MESSAGE_PREFIX}frame-clicked`:
                window.elementPickerInstance.pauseAndTakeControl(payload.path);
                break;
            case `${MESSAGE_PREFIX}frame-quit`:
                window.elementPickerInstance.cleanup();
                break;
        }
    } 
    else if (!isTopFrame && window.elementPickerInstance) {
         switch (type) {
            case `${MESSAGE_PREFIX}pause-all`: window.elementPickerInstance.pause(); break;
            case `${MESSAGE_PREFIX}resume-all`: window.elementPickerInstance.resume(); break;
            case `${MESSAGE_PREFIX}update-selection`: 
                currentSelector = payload.selector;
                currentMode = payload.mode;
                window.elementPickerInstance.drawSelection(payload.selector, payload.mode); 
                break;
            case `${MESSAGE_PREFIX}apply-rule`: 
                window.elementPickerInstance.applyDisplayRule(payload.selector, payload.display); 
                break;
            case `${MESSAGE_PREFIX}shutdown-all`: window.elementPickerInstance.cleanup(); break;
        }
    }
});


function initialize() {
    if (window.elementPickerHasRun) return;
    window.elementPickerHasRun = true;

    let isPaused = false;
    let isDragging = false;
    let isFrozenByJs = false;
    let lastTarget = null;
    let clickedElementRef = null;
    let fullSelectorPath = [];
    let lastGeneratedPath = [];
    let hiddenSelectors = [];
    let scrollThrottleTimer = null;
    let frozenCssItems = []; 

    const EVENTS_TO_BLOCK = ['mouseout', 'mouseleave', 'blur', 'focusout'];
    
    const eventBlocker = (e) => {
        e.stopPropagation();
    };

    const overlay = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    overlay.id = 'ubo-picker-overlay';
    const hoverHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(hoverHighlightPath);
    const selectionHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(selectionHighlightPath);
    document.body.appendChild(overlay);
    
    const hexToRgba = (hex, alpha = 1) => {
        let r = 0, g = 0, b = 0;
        if (hex.length === 4) { r = "0x" + hex[1] + hex[1]; g = "0x" + hex[2] + hex[2]; b = "0x" + hex[3] + hex[3]; } 
        else if (hex.length === 7) { r = "0x" + hex[1] + hex[2]; g = "0x" + hex[3] + hex[4]; b = "0x" + hex[5] + hex[6]; }
        return `rgba(${+r},${+g},${+b},${alpha})`;
    };
    
    const setPathStyles = (path, color) => {
        path.style.setProperty('fill', hexToRgba(color, 0.2), 'important');
        path.style.setProperty('stroke', color, 'important');
        path.style.setProperty('stroke-width', '1px', 'important');
    };
    
    setPathStyles(hoverHighlightPath, '#0064FF');
    setPathStyles(selectionHighlightPath, '#FF0000');
    
    const getSelectorForPart = (part) => {
        const tag = part.tag;
        const id = (part.id && part.isIdUnique) ? `#${CSS.escape(part.id)}` : null;
        const classes = part.classes.filter(c => !c.startsWith('ubo-picker-')).sort().map(c => `.${CSS.escape(c)}`).join('');
        return id || (classes ? `${tag}${classes}` : tag);
    };
    
    const drawSelection = (selector, mode = 'similar') => {
        let selectionPathData = '';
        try {
            if (!selector) {
                highlightedElementForCopy = null;
            } else if (mode === 'single') {
                const el = document.querySelector(selector);
                highlightedElementForCopy = el;
                if (el) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 || rect.height > 0) {
                        selectionPathData = `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `;
                    }
                }
            } else { // 'similar' mode
                const matchedElements = document.querySelectorAll(selector);
                highlightedElementForCopy = matchedElements.length > 0 ? matchedElements[0] : null;
                matchedElements.forEach(el => {
                    if (el.classList.contains('ubo-picker-ignore')) return;
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 || rect.height > 0) {
                       selectionPathData += `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `;
                    }
                });
            }
        } catch (e) { 
            highlightedElementForCopy = null;
            if(isTopFrame) document.getElementById('ubo-picker-hide-button').disabled = true;
        }
        selectionHighlightPath.setAttribute('d', selectionPathData);
    };

    const mouseMoveHandler = (e) => {
        if (isPaused || (isTopFrame && isDragging)) return;
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) {
            hoverHighlightPath.setAttribute('d', '');
            lastTarget = null;
            return;
        }
        if (target === lastTarget) return;
        lastTarget = target;
        const rect = target.getBoundingClientRect();
        hoverHighlightPath.setAttribute('d', `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z`);
    };
    
    const generatePathForElement = (element) => {
        const path = [];
        let current = element;
        while (current && current.tagName !== 'HTML') {
            let nth = 1;
            let sibling = current.previousElementSibling;
            while(sibling) {
                if (sibling.tagName === current.tagName) nth++;
                sibling = sibling.previousElementSibling;
            }
            let isIdUnique = true;
            if (current.id) {
                if (document.querySelectorAll('#' + CSS.escape(current.id)).length > 1) {
                    isIdUnique = false;
                }
            }
            path.unshift({ 
                tag: current.tagName.toLowerCase(), 
                id: current.id, 
                classes: Array.from(current.classList), 
                nth: nth,
                isIdUnique: isIdUnique
            });
            current = current.parentElement;
        }
        return path;
    };
    
    const clickHandler = (e) => {
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) return;
        e.preventDefault();
        e.stopPropagation();
        clickedElementRef = target;
        const path = generatePathForElement(target);
        if (isTopFrame) {
            pauseAndTakeControl(path);
        } else {
            window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-clicked`, payload: { path } }, '*');
        }
    };
    
    const repositionFrozenOverlays = () => {
        frozenCssItems.forEach(item => {
            const rect = item.element.getBoundingClientRect();
            item.overlayDiv.style.left = `${rect.left + window.scrollX}px`;
            item.overlayDiv.style.top = `${rect.top + window.scrollY}px`;
            item.overlayDiv.style.width = `${rect.width}px`;
            item.overlayDiv.style.height = `${rect.height}px`;
        });
    };

    const keydownHandler = (e) => {
        if (e.key === 'Escape') {
            e.preventDefault(); e.stopPropagation();
            if (isTopFrame) cleanup(); else window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-quit` }, '*');
        }
        if (isTopFrame && e.key.toLowerCase() === 'z' && !e.ctrlKey && !e.altKey && !e.metaKey) {
            e.preventDefault(); e.stopPropagation();
            if (window.elementPickerInstance) window.elementPickerInstance.toggleCssFreeze();
        }
    };
    
    const applyDisplayRule = (selector, displayValue) => {
        if (!selector) return;
        try { document.querySelectorAll(selector).forEach(el => {
            if (displayValue === '') el.style.removeProperty('display');
            else el.style.setProperty('display', displayValue, 'important');
        }); } catch (e) { console.error("Error applying visibility rule:", selector, e); }
    };

    const throttledRedraw = () => {
        if (scrollThrottleTimer) return;
        scrollThrottleTimer = setTimeout(() => {
            if (isPaused) {
                if (isTopFrame) generateAndDraw();
                else drawSelection(currentSelector, currentMode);
            }
            repositionFrozenOverlays();
            scrollThrottleTimer = null;
        }, 50);
    };

    const cleanup = () => {
        if (!window.elementPickerHasRun) return;

        frozenCssItems.forEach(item => {
            if (item.overlayDiv.parentNode) item.overlayDiv.parentNode.removeChild(item.overlayDiv);
            item.subMenu.style.cssText = item.originalStyle;
        });
        frozenCssItems = [];
        
        if (isFrozenByJs) {
            EVENTS_TO_BLOCK.forEach(eventType => window.removeEventListener(eventType, eventBlocker, true));
            isFrozenByJs = false;
        }

        if (isTopFrame) {
            if (hiddenSelectors.length > 0) {
                hiddenSelectors.forEach(selector => {
                    const selectorToShow = selector.startsWith('##') ? selector.substring(2) : selector;
                    applyDisplayRule(selectorToShow, '');
                    activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' } }, '*'));
                });
            }
            activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}shutdown-all` }, '*'));
            const panel = document.getElementById('ubo-picker-panel');
            if(panel && panel.parentNode) panel.parentNode.removeChild(panel);
        }
        document.body.classList.remove('ubo-picker-active');
        document.removeEventListener('mousemove', mouseMoveHandler, true);
        document.removeEventListener('click', clickHandler, true);
        document.removeEventListener('keydown', keydownHandler, true);
        document.removeEventListener('scroll', throttledRedraw, true);
        window.removeEventListener('resize', throttledRedraw);
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        window.elementPickerHasRun = false;
        window.elementPickerInstance = null;
    };
    
    const pause = () => {
        isPaused = true;
        hoverHighlightPath.setAttribute('d', '');
        document.body.classList.remove('ubo-picker-active');
    };
    
    const resume = () => {
        isPaused = false;
        clickedElementRef = null;
        selectionHighlightPath.setAttribute('d', '');
        document.body.classList.add('ubo-picker-active');
    };

    document.body.classList.add('ubo-picker-active');
    document.addEventListener('mousemove', mouseMoveHandler, true);
    document.addEventListener('click', clickHandler, true);
    document.addEventListener('keydown', keydownHandler, true);
    document.addEventListener('scroll', throttledRedraw, true);
    window.addEventListener('resize', throttledRedraw);

    let panel, filterDisplay, quitButton, moveHandle, pathSlider, pathSliderPrevBtn, pathSliderNextBtn, pathSliderLabel, pathTicksContainer, selectButton, clearButton, copyButton, hideButton, showButton, undoButton, minimizeButton, hoverColorInput, selectionColorInput, shortSelectorCheckbox, similarCheckbox, insideCheckbox, freezeButton;
    
    if (isTopFrame) {
        panel = document.createElement('aside');
        panel.id = 'ubo-picker-panel';
        panel.innerHTML = `
            <div id="ubo-picker-window-bar">
                <div id="ubo-picker-move-handle"></div>
                <div id="ubo-picker-controls-container">
                    <input type="color" id="ubo-picker-hover-color-input" class="ubo-picker-color-swatch" title="Change hover color" value="#0064FF">
                    <input type="color" id="ubo-picker-selection-color-input" class="ubo-picker-color-swatch" title="Change selection color" value="#FF0000">
                    <button id="ubo-picker-freeze-button" title="Freeze dynamic elements (Blocks JS events)">❄️</button>
                    <button id="ubo-picker-minimize-button" title="Minimize">_</button>
                    <button id="ubo-picker-quit" title="Quit (Esc)">×</button>
                </div>
            </div>
            <div id="ubo-picker-content">
                <div id="ubo-picker-filter-display" contenteditable="true" spellcheck="false"></div>
                <fieldset id="ubo-picker-copy-options">
                    <legend>Copy Mode</legend>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-filter" value="filter"><label for="copy-mode-filter">##</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-js" value="js"><label for="copy-mode-js">JS</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-ohtml" value="o.HTML"><label for="copy-mode-ohtml">o.HTML</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-element" value="element"><label for="copy-mode-element">Element</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-styles" value="styles"><label for="copy-mode-styles">Styles</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-xpath" value="xpath"><label for="copy-mode-xpath">XPath</label></div>
                    <div class="ubo-picker-radio-item"><input type="radio" name="copy-mode" id="copy-mode-fxpath" value="fxpath"><label for="copy-mode-fxpath">F.XPath</label></div>
                </fieldset>
                <div id="ubo-picker-sliders">
                    <div class="ubo-picker-slider-container">
                        <span id="ubo-picker-path-slider-label" class="ubo-picker-slider-label">UP</span>
                        <div class="ubo-picker-slider-with-arrows">
                            <button id="ubo-picker-path-slider-prev" class="ubo-picker-slider-arrow" disabled><</button>
                            <div class="ubo-picker-slider-wrapper">
                                <input type="range" min="0" max="0" value="0" id="ubo-picker-path-slider" disabled>
                                <div id="ubo-picker-path-ticks-container"></div>
                            </div>
                            <button id="ubo-picker-path-slider-next" class="ubo-picker-slider-arrow" disabled>></button>
                        </div>
                    </div>
                </div>
                <div id="ubo-picker-actions">
                    <div class="ubo-picker-checkbox-container">
                        <div class="ubo-picker-checkbox-item"><input type="checkbox" id="ubo-picker-inside-checkbox" disabled><label for="ubo-picker-inside-checkbox">Inside</label></div>
                        <div class="ubo-picker-checkbox-item"><input type="checkbox" id="ubo-picker-similar-checkbox" disabled><label for="ubo-picker-similar-checkbox">Similar</label></div>
                        <div class="ubo-picker-checkbox-item"><input type="checkbox" id="ubo-picker-short-selector-checkbox" disabled><label for="ubo-picker-short-selector-checkbox">Short</label></div>
                    </div>
                    <button id="ubo-picker-select-button" disabled>SELECT</button><button id="ubo-picker-clear-button" disabled>CLEAR</button><button id="ubo-picker-hide-button" disabled>HIDE</button><button id="ubo-picker-undo-button" disabled>UNDO</button><button id="ubo-picker-show-button" disabled>SHOW</button><button id="ubo-picker-copy-button" disabled>COPY</button>
                </div>
            </div>
        `;
        panel.querySelectorAll('*').forEach(el => el.classList.add('ubo-picker-ignore'));
        panel.classList.add('ubo-picker-ignore');
        document.body.appendChild(panel);

        filterDisplay = document.getElementById('ubo-picker-filter-display'); quitButton = document.getElementById('ubo-picker-quit'); moveHandle = document.getElementById('ubo-picker-move-handle'); pathSlider = document.getElementById('ubo-picker-path-slider'); pathSliderLabel = document.getElementById('ubo-picker-path-slider-label'); pathTicksContainer = document.getElementById('ubo-picker-path-ticks-container'); selectButton = document.getElementById('ubo-picker-select-button'); clearButton = document.getElementById('ubo-picker-clear-button'); copyButton = document.getElementById('ubo-picker-copy-button'); hideButton = document.getElementById('ubo-picker-hide-button'); showButton = document.getElementById('ubo-picker-show-button'); undoButton = document.getElementById('ubo-picker-undo-button'); minimizeButton = document.getElementById('ubo-picker-minimize-button'); hoverColorInput = document.getElementById('ubo-picker-hover-color-input'); selectionColorInput = document.getElementById('ubo-picker-selection-color-input'); shortSelectorCheckbox = document.getElementById('ubo-picker-short-selector-checkbox'); similarCheckbox = document.getElementById('ubo-picker-similar-checkbox'); insideCheckbox = document.getElementById('ubo-picker-inside-checkbox'); freezeButton = document.getElementById('ubo-picker-freeze-button');
        pathSliderPrevBtn = document.getElementById('ubo-picker-path-slider-prev');
        pathSliderNextBtn = document.getElementById('ubo-picker-path-slider-next');
    }
    
    const buildPreciseSelectorFromPath = (path) => {
        if (!path || path.length === 0) return '';
        return path.map(part => {
            if (part.id && part.isIdUnique) {
                return `#${CSS.escape(part.id)}`;
            }
            let selectorPart = part.tag;
            const classes = part.classes.filter(c => !c.startsWith('ubo-picker-')).map(c => `.${CSS.escape(c)}`).join('');
            selectorPart += classes;
            selectorPart += `:nth-of-type(${part.nth})`;
            return selectorPart;
        }).join(' > ');
    };

    const generateXPath = (element, full = false) => {
        if (!element || element.nodeType !== Node.ELEMENT_NODE) { return ''; }
        if (element.id && !full) { return `//*[@id="${element.id}"]`; }
        if (full) {
            let path = '';
            for (; element && element.nodeType === Node.ELEMENT_NODE; element = element.parentNode) {
                let index = 0;
                let hasSameNamedSibling = false;
                for (let sibling = element.previousElementSibling; sibling; sibling = sibling.previousElementSibling) {
                    if (sibling.nodeType === Node.DOCUMENT_TYPE_NODE) continue;
                    if (sibling.nodeName === element.nodeName) ++index;
                }
                for (let sibling = element.nextSibling; sibling && !hasSameNamedSibling; sibling = sibling.nextSibling) {
                    if (sibling.nodeName === element.nodeName) hasSameNamedSibling = true;
                }
                const tagName = element.nodeName.toLowerCase();
                const pathIndex = (hasSameNamedSibling || index > 0) ? `[${index + 1}]` : '';
                path = `/${tagName}${pathIndex}` + path;
            }
            return path;
        } else {
             return `//${element.tagName.toLowerCase()}`;
        }
    };

    const getDevtoolsStylesAsString = (element) => {
        if (!element) return '';
    
        const styleCategories = {
            'Layout & Box Model': ['display', 'position', 'top', 'right', 'bottom', 'left', 'float', 'clear', 'z-index', 'width', 'height', 'margin', 'padding', 'border', 'box-sizing', 'overflow', 'resize'],
            'Flexbox': ['flex', 'flex-basis', 'flex-direction', 'flex-flow', 'flex-grow', 'flex-shrink', 'flex-wrap', 'align-content', 'align-items', 'align-self', 'justify-content', 'order'],
            'Grid': ['grid', 'grid-area', 'grid-auto-columns', 'grid-auto-flow', 'grid-auto-rows', 'grid-column', 'grid-row', 'grid-template'],
            'Text & Font': ['font', 'font-family', 'font-size', 'font-weight', 'font-style', 'font-variant', 'line-height', 'letter-spacing', 'word-spacing', 'color', 'text-align', 'text-decoration', 'text-indent', 'text-transform', 'white-space', 'vertical-align', 'word-break', 'writing-mode', 'caret-color', 'text-emphasis', '-webkit-text-fill-color', '-webkit-text-stroke'],
            'Appearance & Decoration': ['background', 'box-shadow', 'border-radius', 'opacity', 'visibility', 'cursor', 'outline', 'list-style', 'scrollbar-color', 'scrollbar-width'],
            'Animation & Transition': ['transition', 'animation', 'transform', 'transform-origin', 'perspective', 'will-change'],
            'Other': []
        };
    
        const findCategory = (prop) => {
            for (const cat in styleCategories) {
                if (cat === 'Other') continue;
                for (const prefix of styleCategories[cat]) {
                    if (prop.startsWith(prefix)) {
                        return cat;
                    }
                }
            }
            return 'Other';
        };
    
        const computedStyles = window.getComputedStyle(element);
        const defaultElement = document.createElement(element.tagName);
        document.body.appendChild(defaultElement);
        const defaultStyles = window.getComputedStyle(defaultElement);
    
        const categorized = {
            different: {},
            same: {}
        };
    
        for (const cat in styleCategories) {
            categorized.different[cat] = [];
            categorized.same[cat] = [];
        }
    
        for (const prop of computedStyles) {
            const elementValue = computedStyles.getPropertyValue(prop);
            const defaultValue = defaultStyles.getPropertyValue(prop);
            const category = findCategory(prop);
            const styleLine = `    ${prop}: ${elementValue};`;
    
            if (elementValue !== defaultValue) {
                categorized.different[category].push(styleLine);
            } else {
                categorized.same[category].push(styleLine);
            }
        }
    
        document.body.removeChild(defaultElement);
    
        let result = '';
        if (element.style.cssText) {
            result += `element.style {\n    ${element.style.cssText.replace(/; /g, ';\n    ').replace(/;$/, '')}\n}\n\n`;
        }
    
        const hasDifferentStyles = Object.values(categorized.different).some(arr => arr.length > 0);
        if (hasDifferentStyles) {
            result += '/* --- Custom & Overridden Styles --- */\n\n';
            for (const cat in styleCategories) {
                if (categorized.different[cat].length > 0) {
                    result += `/* ${cat} */\n`;
                    result += categorized.different[cat].sort().join('\n');
                    result += '\n\n';
                }
            }
        }
    
        const hasSameStyles = Object.values(categorized.same).some(arr => arr.length > 0);
        if (hasSameStyles) {
            result += '/* --- Default Computed Styles (unchanged) --- */\n\n';
            for (const cat in styleCategories) {
                if (categorized.same[cat].length > 0) {
                    result += `/* ${cat} */\n`;
                    result += categorized.same[cat].sort().join('\n');
                    result += '\n\n';
                }
            }
        }
    
        return result.trim();
    };
    
    const generateAndDraw = () => {
        if (!isPaused || !fullSelectorPath || fullSelectorPath.length === 0) return;

        const isInsideMode = insideCheckbox.checked;
        const isSimilarMode = similarCheckbox.checked;
        const isShortMode = shortSelectorCheckbox.checked;
        
        pathSliderLabel.textContent = isInsideMode ? 'DOWN' : 'UP';
        
        let currentPath = [];
        let textNodeInfo = '';
        let traversableNodesCount = 0;

        pathTicksContainer.innerHTML = '';

        if (isInsideMode) {
            const baseSelector = buildPreciseSelectorFromPath(fullSelectorPath);
            const containerElement = document.querySelector(baseSelector);
            if (!containerElement) return;

            const walker = document.createTreeWalker(containerElement, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null, false);
            const traversableNodes = [];
            let node = walker.currentNode;
            while(node) {
                 if (node.nodeType === 3 && node.textContent.trim().length === 0) {
                    // skip empty text nodes
                 } else {
                    traversableNodes.push(node);
                 }
                node = walker.nextNode();
            }

            traversableNodesCount = traversableNodes.length;
            pathSlider.max = traversableNodesCount > 0 ? traversableNodesCount - 1 : 0;
            const nodeIndex = Math.min(parseInt(pathSlider.value, 10), pathSlider.max);
            const targetNode = traversableNodes[nodeIndex];
            
            if (targetNode) {
                 const elementToProcess = (targetNode.nodeType === Node.TEXT_NODE) ? targetNode.parentNode : targetNode;
                 currentPath = generatePathForElement(elementToProcess);
                 if (targetNode.nodeType === Node.TEXT_NODE) textNodeInfo = ' (:dla węzła #text)';
            }
            
            // Draw ticks for DOWN mode
            const numTicks = traversableNodesCount - 1;
            if (numTicks >= 0) {
                for (let i=0; i <= numTicks; i++) {
                    const tick = document.createElement('div');
                    tick.className = 'tick';
                    pathTicksContainer.appendChild(tick);
                }
            }
        } else { // UP Mode
            traversableNodesCount = fullSelectorPath.length;
            pathSlider.max = traversableNodesCount > 0 ? traversableNodesCount - 1 : 0;
            const pathIndex = Math.min(parseInt(pathSlider.value, 10), pathSlider.max);
            currentPath = fullSelectorPath.slice(0, fullSelectorPath.length - pathIndex);
            
            // Draw ticks for UP mode
            const numTicks = traversableNodesCount - 1;
            if (numTicks >= 0) {
                for (let i=0; i <= numTicks; i++) {
                    const tick = document.createElement('div');
                    tick.className = 'tick';
                    pathTicksContainer.appendChild(tick);
                }
            }
        }

        if (currentPath.length === 0) return;
        
        lastGeneratedPath = JSON.parse(JSON.stringify(currentPath));

        const preciseSelector = buildPreciseSelectorFromPath(currentPath);
        let displaySelector;

        if (isShortMode) {
            const lastPart = currentPath[currentPath.length - 1];
            displaySelector = getSelectorForPart(lastPart);
        } else {
            displaySelector = preciseSelector;
        }

        const selectorForDrawing = isSimilarMode ? displaySelector : preciseSelector;
        const modeForDrawing = isSimilarMode ? 'similar' : 'single';
        
        const displayText = `##${displaySelector}${textNodeInfo}`;
        
        currentSelector = displaySelector;
        if (filterDisplay.textContent !== displayText) {
            filterDisplay.textContent = displayText;
        }
        
        drawSelection(selectorForDrawing, modeForDrawing);
        activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: selectorForDrawing, mode: modeForDrawing } }, '*'));

        pathSliderPrevBtn.disabled = parseInt(pathSlider.value) <= parseInt(pathSlider.min);
        pathSliderNextBtn.disabled = parseInt(pathSlider.value) >= parseInt(pathSlider.max);
    };

    const pauseAndTakeControl = (path) => {
        fullSelectorPath = path;
        lastGeneratedPath = JSON.parse(JSON.stringify(path));
        clickedElementRef = document.querySelector(buildPreciseSelectorFromPath(path));
        pause();
        activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}pause-all` }, '*'));
        
        selectButton.disabled = false; clearButton.disabled = false; copyButton.disabled = false; hideButton.disabled = false;
        insideCheckbox.disabled = false; insideCheckbox.checked = false;
        similarCheckbox.disabled = false; similarCheckbox.checked = false;
        shortSelectorCheckbox.disabled = false; shortSelectorCheckbox.checked = false;
        pathSlider.disabled = false; pathSlider.value = 0;
        pathSliderPrevBtn.disabled = false;
        pathSliderNextBtn.disabled = false;
        
        generateAndDraw();
    };

    if (isTopFrame) {
        const clearSelectionHandler = () => {
            fullSelectorPath = []; lastGeneratedPath = []; clickedElementRef = null; currentSelector = '';
            drawSelection('');
            activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: '', mode: 'similar' }}, '*'));
            filterDisplay.textContent = '';
            pathTicksContainer.innerHTML = '';
            
            clearButton.disabled = true; copyButton.disabled = true; hideButton.disabled = true;

            [insideCheckbox, similarCheckbox, shortSelectorCheckbox].forEach(cb => { cb.disabled = true; cb.checked = false; });
            pathSlider.disabled = true; pathSlider.value = 0;
            pathSliderPrevBtn.disabled = true;
            pathSliderNextBtn.disabled = true;
            pathSliderLabel.textContent = 'UP';
        };

        const clearCssFreeze = () => {
            frozenCssItems.forEach(item => {
                if (item.overlayDiv.parentNode) item.overlayDiv.parentNode.removeChild(item.overlayDiv);
                item.subMenu.style.cssText = item.originalStyle;
            });
            frozenCssItems = [];
            if (!isFrozenByJs) {
                freezeButton.classList.remove('active');
            }
            clearSelectionHandler();
        };
        
        const clearJsFreeze = () => {
            if (!isFrozenByJs) return;
            isFrozenByJs = false;
            EVENTS_TO_BLOCK.forEach(eventType => window.removeEventListener(eventType, eventBlocker, true));
            if (frozenCssItems.length === 0) {
                freezeButton.classList.remove('active');
            }
            clearSelectionHandler();
        };

        const toggleJsFreeze = () => {
            if (isFrozenByJs) {
                clearJsFreeze();
            } else {
                clearCssFreeze();
                isFrozenByJs = true;
                freezeButton.classList.add('active');
                EVENTS_TO_BLOCK.forEach(eventType => window.addEventListener(eventType, eventBlocker, true));
            }
        };

        const toggleCssFreeze = () => {
            if (frozenCssItems.length > 0) {
                clearCssFreeze();
            } else {
                clearJsFreeze();
                if (!lastTarget) return;
                const targetLi = lastTarget.closest('li');
                if (!targetLi) return;
                const subMenu = targetLi.querySelector('ul, div');
                if (!subMenu) return;

                const originalStyle = subMenu.style.cssText;
                const computed = window.getComputedStyle(subMenu);
                const styleToApply = `display: ${computed.display}; visibility: ${computed.visibility}; opacity: ${computed.opacity}; position: ${computed.position}; top: ${computed.top}; left: ${computed.left}; width: ${computed.width}; height: ${computed.height}; transform: ${computed.transform}; z-index: ${computed.zIndex};`;
                subMenu.style.cssText = originalStyle + styleToApply;

                const overlayDiv = document.createElement('div');
                overlayDiv.className = 'ubo-picker-frozen-overlay';
                document.body.appendChild(overlayDiv);
                frozenCssItems.push({ element: targetLi, subMenu: subMenu, overlayDiv: overlayDiv, originalStyle: originalStyle });
                
                freezeButton.classList.add('active');
                repositionFrozenOverlays();
            }
        };
        
        const copyHandler = () => {
            const copyMode = document.querySelector('input[name="copy-mode"]:checked')?.value;
            const element = highlightedElementForCopy;
            let textToCopy = '';

            if (!element) return;
            
            const selectorForDisplay = currentSelector; 

            switch (copyMode) {
                case 'filter':
                    textToCopy = filterDisplay.textContent.replace(/\s*\(:dla węzła #text\)$/, '');
                    break;
                case 'js':
                    textToCopy = `document.querySelector("${selectorForDisplay}")`;
                    break;
                case 'element':
                case 'o.HTML':
                    if (element && element.shadowRoot) {
                        const outer = element.outerHTML;
                        const inner = element.shadowRoot.innerHTML;
                        const tag = element.tagName.toLowerCase();
                        const openingTag = outer.substring(0, outer.indexOf('>') + 1);
                        textToCopy = `${openingTag}\n  <!-- Shadow Root (open) -->\n  ${inner}\n  <!-- End Shadow Root -->\n</${tag}>`;
                    } else {
                        textToCopy = element.outerHTML;
                    }
                    break;
                case 'styles':
                    textToCopy = getDevtoolsStylesAsString(element);
                    break;
                case 'xpath':
                    textToCopy = generateXPath(element, false);
                    break;
                case 'fxpath':
                    textToCopy = generateXPath(element, true);
                    break;
                default:
                    textToCopy = selectorForDisplay;
                    break;
            }

            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    copyButton.textContent = 'COPIED!';
                    setTimeout(() => { copyButton.textContent = 'COPY'; }, 1000);
                });
            }
        };

        const reselectHandler = () => { clearSelectionHandler(); resume(); activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}resume-all` }, '*')); selectButton.disabled = true; };
        const hideHandler = () => { 
            let selectorToHide = filterDisplay.textContent.trim();
            if (!selectorToHide) return;
            selectorToHide = selectorToHide.replace(/\s*\(:dla węzła #text\)$/, '');
            if (!hiddenSelectors.includes(selectorToHide)) hiddenSelectors.push(selectorToHide); 
            const cleanSelector = selectorToHide.startsWith('##') ? selectorToHide.substring(2) : selectorToHide; 
            applyDisplayRule(cleanSelector, 'none'); 
            activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: cleanSelector, display: 'none' }}, '*')); 
            drawSelection(''); 
            activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: '', mode: 'similar' }}, '*')); 
            showButton.disabled = false; 
            undoButton.disabled = false; 
        };
        const undoHandler = () => { if (hiddenSelectors.length === 0) return; const selectorToUndo = hiddenSelectors.pop(); const selectorToShow = selectorToUndo.startsWith('##') ? selectorToUndo.substring(2) : selectorToUndo; applyDisplayRule(selectorToShow, ''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' }}, '*')); if (hiddenSelectors.length === 0) { showButton.disabled = true; undoButton.disabled = true; } generateAndDraw(); };
        const showHandler = () => { if (hiddenSelectors.length === 0) return; hiddenSelectors.forEach(selector => { const selectorToShow = selector.startsWith('##') ? selector.substring(2) : selector; applyDisplayRule(selectorToShow, ''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' }}, '*')); }); hiddenSelectors = []; showButton.disabled = true; undoButton.disabled = true; generateAndDraw(); };
        const toggleMinimizeHandler = () => { panel.classList.toggle('ubo-picker-minimized'); };
        let pos1=0, pos2=0, pos3=0, pos4=0; function dragMouseDown(e) { e = e || window.event; e.preventDefault(); const rect = panel.getBoundingClientRect(); panel.style.top = rect.top + 'px'; panel.style.left = rect.left + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto'; pos3 = e.clientX; pos4 = e.clientY; document.onmouseup = closeDragElement; document.onmousemove = elementDrag; isDragging = true; } function elementDrag(e) { e = e || window.event; e.preventDefault(); pos1 = pos3 - e.clientX; pos2 = pos4 - e.clientY; pos3 = e.clientX; pos4 = e.clientY; panel.style.top = (panel.offsetTop - pos2) + "px"; panel.style.left = (panel.offsetLeft - pos1) + "px"; } function closeDragElement() { document.onmouseup = null; document.onmousemove = null; isDragging = false; }

        quitButton.addEventListener('click', cleanup); 
        moveHandle.addEventListener('mousedown', dragMouseDown); 
        selectButton.addEventListener('click', reselectHandler); 
        clearButton.addEventListener('click', clearSelectionHandler); 
        copyButton.addEventListener('click', copyHandler); 
        hideButton.addEventListener('click', hideHandler); 
        undoButton.addEventListener('click', undoHandler); 
        showButton.addEventListener('click', showHandler); 
        minimizeButton.addEventListener('click', toggleMinimizeHandler); 
        freezeButton.addEventListener('click', toggleJsFreeze);
        
        pathSlider.addEventListener('input', generateAndDraw);
        pathSliderPrevBtn.addEventListener('click', () => {
            pathSlider.stepDown();
            generateAndDraw();
        });
        pathSliderNextBtn.addEventListener('click', () => {
            pathSlider.stepUp();
            generateAndDraw();
        });

        similarCheckbox.addEventListener('change', generateAndDraw);
        shortSelectorCheckbox.addEventListener('change', generateAndDraw);

        insideCheckbox.addEventListener('change', function() {
            if (this.checked) {
                fullSelectorPath = lastGeneratedPath;
            }
            pathSlider.value = 0;
            generateAndDraw();
        });

        const copyModeRadios = document.querySelectorAll('input[name="copy-mode"]');
        let lastCheckedRadio = null;
        copyModeRadios.forEach(radio => {
            radio.addEventListener('click', function(e) {
                if (this === lastCheckedRadio && this.checked) {
                    this.checked = false;
                    lastCheckedRadio = null;
                } else {
                    lastCheckedRadio = this;
                }
            });
        });

        filterDisplay.addEventListener('input', () => {});
        hoverColorInput.addEventListener('input', () => { const newColor = hoverColorInput.value; setPathStyles(hoverHighlightPath, newColor); chrome.runtime.sendMessage({ type: 'saveHoverColor', color: newColor }); });
        selectionColorInput.addEventListener('input', () => { const newColor = selectionColorInput.value; setPathStyles(selectionHighlightPath, newColor); chrome.runtime.sendMessage({ type: 'saveSelectionColor', color: newColor }); });
        chrome.runtime.sendMessage({ type: 'getColors' }, (response) => { if (response) { if (response.hoverColor) { hoverColorInput.value = response.hoverColor; setPathStyles(hoverHighlightPath, response.hoverColor); } if (response.selectionColor) { selectionColorInput.value = response.selectionColor; setPathStyles(selectionHighlightPath, response.selectionColor); } } });

        window.elementPickerInstance = { cleanup, pause, resume, drawSelection, applyDisplayRule, pauseAndTakeControl, toggleCssFreeze, toggleJsFreeze };
    } else {
        window.elementPickerInstance = { cleanup, pause, resume, drawSelection, applyDisplayRule };
    }

    if (!isTopFrame) window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-ready` }, '*');
}