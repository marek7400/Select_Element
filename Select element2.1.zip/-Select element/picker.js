(function() {
    if (window.elementPickerHasRun) return;
    window.elementPickerHasRun = true;

    let isPaused = false;
    let isDragging = false;
    let lastTarget = null;
    let elementHierarchy = []; // [kliknięty, rodzic, dziadek, ...]
    let fullSelectorPath = []; // Przechowuje teraz tylko {element}, bez pre-generowanego selektora
    let hiddenSelector = null;
    
    // === ZMIANA: Zmienne do przechowywania timerów dla debouncingu ===
    let hoverColorSaveTimer = null;
    let selectionColorSaveTimer = null;

    // --- UI Elements ---
    const overlay = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    overlay.id = 'ubo-picker-overlay';
    const hoverHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(hoverHighlightPath);
    const selectionHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(selectionHighlightPath);

    const panel = document.createElement('aside');
    panel.id = 'ubo-picker-panel';
    panel.innerHTML = `
        <div id="ubo-picker-window-bar">
            <div id="ubo-picker-move-handle"></div>
            <div id="ubo-picker-controls-container">
                <input type="color" id="ubo-picker-hover-color-input" class="ubo-picker-color-swatch" title="Zmień kolor wyszukiwania" value="#0064FF">
                <input type="color" id="ubo-picker-selection-color-input" class="ubo-picker-color-swatch" title="Zmień kolor zaznaczenia" value="#FF0000">
                <button id="ubo-picker-minimize-button" title="Minimalizuj">_</button>
                <button id="ubo-picker-quit" title="Zakończ (Esc)">×</button>
            </div>
        </div>
        <div id="ubo-picker-content">
            <div id="ubo-picker-filter-display" contenteditable="true" spellcheck="false"></div>
            <div id="ubo-picker-sliders">
                <div class="ubo-picker-slider-container">
                    <div class="ubo-picker-slider-wrapper">
                        <input type="range" min="0" max="0" value="0" id="ubo-picker-path-slider" disabled>
                        <div id="ubo-picker-path-ticks-container"></div>
                    </div>
                </div>
                <div class="ubo-picker-slider-container">
                    <input type="range" min="0" max="3" value="3" id="ubo-picker-attr-slider" disabled>
                </div>
            </div>
            <div id="ubo-picker-actions">
                <div class="ubo-picker-checkbox-container">
                    <input type="checkbox" id="ubo-picker-short-selector-checkbox" disabled>
                    <label for="ubo-picker-short-selector-checkbox">Short</label>
                </div>
                <button id="ubo-picker-select-button" disabled>SELECT</button>
                <button id="ubo-picker-clear-button" disabled>CLEAR</button>
                <button id="ubo-picker-hide-button" disabled>HIDE</button>
                <button id="ubo-picker-show-button" disabled>SHOW</button>
                <button id="ubo-picker-copy-button" disabled>COPY</button>
            </div>
        </div>
    `;
    
    panel.style.width = (window.screen.width / 4) + 'px';

    panel.querySelectorAll('*').forEach(el => el.classList.add('ubo-picker-ignore'));
    panel.classList.add('ubo-picker-ignore');
    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    const filterDisplay = document.getElementById('ubo-picker-filter-display');
    const quitButton = document.getElementById('ubo-picker-quit');
    const moveHandle = document.getElementById('ubo-picker-move-handle');
    const pathSlider = document.getElementById('ubo-picker-path-slider');
    const pathTicksContainer = document.getElementById('ubo-picker-path-ticks-container');
    const selectButton = document.getElementById('ubo-picker-select-button');
    const clearButton = document.getElementById('ubo-picker-clear-button');
    const copyButton = document.getElementById('ubo-picker-copy-button');
    const hideButton = document.getElementById('ubo-picker-hide-button');
    const showButton = document.getElementById('ubo-picker-show-button');
    const attrSlider = document.getElementById('ubo-picker-attr-slider');
    const minimizeButton = document.getElementById('ubo-picker-minimize-button');
    const hoverColorInput = document.getElementById('ubo-picker-hover-color-input');
    const selectionColorInput = document.getElementById('ubo-picker-selection-color-input');
    const shortSelectorCheckbox = document.getElementById('ubo-picker-short-selector-checkbox');

    // --- Helper Functions ---
    const hexToRgba = (hex, alpha = 1) => {
        let r = 0, g = 0, b = 0;
        if (hex.length === 4) {
            r = "0x" + hex[1] + hex[1];
            g = "0x" + hex[2] + hex[2];
            b = "0x" + hex[3] + hex[3];
        } else if (hex.length === 7) {
            r = "0x" + hex[1] + hex[2];
            g = "0x" + hex[3] + hex[4];
            b = "0x" + hex[5] + hex[6];
        }
        return `rgba(${+r},${+g},${+b},${alpha})`;
    };

    const getSelectorForElement = (elem, level) => {
        const tag = elem.tagName.toLowerCase();
        const id = elem.id ? `#${CSS.escape(elem.id)}` : null;
        const classes = Array.from(elem.classList)
            .filter(c => !c.startsWith('ubo-picker-'))
            .sort()
            .map(c => `.${CSS.escape(c)}`)
            .join('');

        switch (level) {
            case 0: return tag;
            case 1: return id ? id : tag;
            case 2: return classes ? classes : tag;
            case 3: default:
                if (id) return id;
                if (classes) return classes;
                return tag;
        }
    };

    const applyDisplayRule = (selector, displayValue) => {
        if (!selector) return;
        try {
            document.querySelectorAll(selector).forEach(el => {
                if (displayValue === '') el.style.removeProperty('display');
                else el.style.setProperty('display', displayValue, 'important');
            });
        } catch (e) { console.error("Błąd przy stosowaniu reguły widoczności:", selector, e); }
    };

    const cleanup = () => {
        if (hiddenSelector) {
            const selector = hiddenSelector.startsWith('##') ? hiddenSelector.substring(2) : hiddenSelector;
            applyDisplayRule(selector, '');
        }
        document.body.classList.remove('ubo-picker-active');
        document.removeEventListener('mousemove', mouseMoveHandler, true);
        document.removeEventListener('click', clickHandler, true);
        document.removeEventListener('keydown', keydownHandler, true);
        document.removeEventListener('scroll', generateAndDraw, true);
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        if (panel.parentNode) panel.parentNode.removeChild(panel);
        window.elementPickerHasRun = false;
    };

    const generateAndDraw = () => {
        if (!isPaused || fullSelectorPath.length === 0) return;
        
        const pathIndex = parseInt(pathSlider.value, 10);
        const attrLevel = parseInt(attrSlider.value, 10);
        const isShortMode = shortSelectorCheckbox.checked;

        const currentPath = fullSelectorPath.slice(0, fullSelectorPath.length - pathIndex);
        let finalSelector = '';

        if (isShortMode) {
            // Tryb "Short": bierzemy tylko ostatni element
            const lastElementInPath = currentPath[currentPath.length - 1];
            if (lastElementInPath) {
                finalSelector = getSelectorForElement(lastElementInPath.element, attrLevel);
            }
        } else {
            // Tryb normalny: budujemy pełną ścieżkę
            const pathParts = currentPath.map(part => getSelectorForElement(part.element, attrLevel));
            finalSelector = pathParts.join(' > ');
        }
        
        if (filterDisplay.textContent !== `##${finalSelector}`) {
            filterDisplay.textContent = `##${finalSelector}`;
        }

        let selectionPathData = '';
        try {
            const matchedElements = document.querySelectorAll(finalSelector);
            hideButton.disabled = matchedElements.length === 0;
            matchedElements.forEach(el => {
                if (el.classList.contains('ubo-picker-ignore')) return;
                const rect = el.getBoundingClientRect();
                if (rect.width > 0 || rect.height > 0) {
                   selectionPathData += `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `;
                }
            });
        } catch (e) { 
            console.error("Błędny selektor:", finalSelector, e);
            hideButton.disabled = true;
        }
        selectionHighlightPath.setAttribute('d', selectionPathData);
    };

    // --- Event Handlers ---
    const mouseMoveHandler = (e) => {
        if (isPaused || isDragging) return;
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) {
            hoverHighlightPath.setAttribute('d', '');
            lastTarget = null;
            return;
        }
        if (target === lastTarget) return;
        lastTarget = target;
        const rect = target.getBoundingClientRect();
        hoverHighlightPath.setAttribute('d', `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z`);
    };
    
    const clickHandler = (e) => {
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) { return; }
        e.preventDefault();
        e.stopPropagation();
        isPaused = true;
        document.body.classList.remove('ubo-picker-active');
        document.removeEventListener('mousemove', mouseMoveHandler, true);
        document.addEventListener('scroll', generateAndDraw, true);
        hoverHighlightPath.setAttribute('d', '');
        fullSelectorPath = [];
        let current = target;
        while (current && current.tagName !== 'HTML') {
            fullSelectorPath.unshift({ element: current });
            current = current.parentElement;
        }
        pathSlider.max = fullSelectorPath.length - 1;
        pathSlider.value = 0;
        pathTicksContainer.innerHTML = ''; 
        if (pathSlider.max > 0) {
            for (let i = 0; i <= pathSlider.max; i++) {
                const tick = document.createElement('div');
                tick.className = 'tick';
                pathTicksContainer.appendChild(tick);
            }
        }
        pathSlider.disabled = false;
        attrSlider.disabled = false;
        attrSlider.value = 3;
        selectButton.disabled = false;
        clearButton.disabled = false;
        copyButton.disabled = false;
        hideButton.disabled = false;
        shortSelectorCheckbox.disabled = false;
        generateAndDraw();
    };

    const copyHandler = () => {
        const textToCopy = filterDisplay.textContent.trim();
        if (textToCopy && navigator.clipboard) {
            navigator.clipboard.writeText(textToCopy).then(() => {
                const originalText = copyButton.textContent;
                copyButton.textContent = 'Skopiowano!';
                setTimeout(() => { copyButton.textContent = originalText; }, 1500);
            }).catch(err => { console.error('Nie udało się skopiować do schowka:', err); });
        }
    };

    const clearSelectionHandler = () => {
        fullSelectorPath = [];
        selectionHighlightPath.setAttribute('d', '');
        filterDisplay.textContent = '';
        pathTicksContainer.innerHTML = '';
        pathSlider.disabled = true;
        pathSlider.value = 0;
        attrSlider.disabled = true;
        clearButton.disabled = true;
        copyButton.disabled = true;
        hideButton.disabled = true;
        shortSelectorCheckbox.disabled = true;
        // USUNIĘTO: shortSelectorCheckbox.checked = false;
    };

    const reselectHandler = () => {
        clearSelectionHandler();
        isPaused = false;
        document.body.classList.add('ubo-picker-active');
        document.addEventListener('mousemove', mouseMoveHandler, true);
        document.removeEventListener('scroll', generateAndDraw, true);
        selectButton.disabled = true;
    };

    const hideHandler = () => {
        if (hiddenSelector) {
            const oldSelector = hiddenSelector.startsWith('##') ? hiddenSelector.substring(2) : hiddenSelector;
            applyDisplayRule(oldSelector, '');
        }
        const selectorToHide = filterDisplay.textContent.trim();
        if (!selectorToHide) return;
        hiddenSelector = selectorToHide;
        const cleanSelector = hiddenSelector.startsWith('##') ? hiddenSelector.substring(2) : hiddenSelector;
        applyDisplayRule(cleanSelector, 'none');
        showButton.disabled = false;
    };

    const showHandler = () => {
        if (!hiddenSelector) return;
        const selectorToShow = hiddenSelector.startsWith('##') ? hiddenSelector.substring(2) : hiddenSelector;
        applyDisplayRule(selectorToShow, '');
        hiddenSelector = null;
        showButton.disabled = true;
    };
    
    const keydownHandler = (e) => {
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            cleanup();
        }
    };
    
    // === ZMIANA: Zastosowano debouncing do zapisu kolorów ===
    const updateHoverColor = (e) => {
        const newColor = e.target.value;
        const newFillColor = hexToRgba(newColor, 0.2);
        
        // 1. Zaktualizuj UI natychmiast
        hoverHighlightPath.style.setProperty('fill', newFillColor, 'important');
        hoverHighlightPath.style.setProperty('stroke', newColor, 'important');
        hoverHighlightPath.style.setProperty('stroke-width', '1px', 'important');
        
        // 2. Opóźnij operację zapisu
        clearTimeout(hoverColorSaveTimer); // Anuluj poprzedni timer
        hoverColorSaveTimer = setTimeout(() => {
            chrome.runtime.sendMessage({ type: 'saveHoverColor', color: newColor });
        }, 500); // Czekaj 500ms przed zapisem
    };
    
    const updateSelectionColor = (e) => {
        const newColor = e.target.value;
        const newFillColor = hexToRgba(newColor, 0.2);
        
        // 1. Zaktualizuj UI natychmiast
        selectionHighlightPath.style.setProperty('fill', newFillColor, 'important');
        selectionHighlightPath.style.setProperty('stroke', newColor, 'important');
        selectionHighlightPath.style.setProperty('stroke-width', '1px', 'important');
        
        // 2. Opóźnij operację zapisu
        clearTimeout(selectionColorSaveTimer); // Anuluj poprzedni timer
        selectionColorSaveTimer = setTimeout(() => {
            chrome.runtime.sendMessage({ type: 'saveSelectionColor', color: newColor });
        }, 500); // Czekaj 500ms przed zapisem
    };

    const toggleMinimizeHandler = () => {
        panel.classList.toggle('ubo-picker-minimized');
        const isMinimized = panel.classList.contains('ubo-picker-minimized');
        if (isMinimized) {
            minimizeButton.innerHTML = '□';
            minimizeButton.title = 'Maksymalizuj';
        } else {
            minimizeButton.innerHTML = '_';
            minimizeButton.title = 'Minimalizuj';
        }
    };

    let pos1=0, pos2=0, pos3=0, pos4=0;
    function dragMouseDown(e) { e.preventDefault(); isDragging = true; pos3 = e.clientX; pos4 = e.clientY; document.addEventListener('mouseup', closeDragElement, true); document.addEventListener('mousemove', elementDrag, true); }
    function elementDrag(e) { e.preventDefault(); pos1 = pos3 - e.clientX; pos2 = pos4 - e.clientY; pos3 = e.clientX; pos4 = e.clientY; panel.style.top = (panel.offsetTop - pos2) + "px"; panel.style.left = (panel.offsetLeft - pos1) + "px"; panel.style.bottom = 'auto'; panel.style.right = 'auto'; }
    function closeDragElement() { isDragging = false; document.removeEventListener('mouseup', closeDragElement, true); document.removeEventListener('mousemove', elementDrag, true); }

    // --- Initialization ---
    document.body.classList.add('ubo-picker-active');
    document.addEventListener('mousemove', mouseMoveHandler, true);
    document.addEventListener('click', clickHandler, true);
    document.addEventListener('keydown', keydownHandler, true);
    quitButton.addEventListener('click', cleanup);
    moveHandle.addEventListener('mousedown', dragMouseDown);
    pathSlider.addEventListener('input', generateAndDraw);
    attrSlider.addEventListener('input', generateAndDraw);
    selectButton.addEventListener('click', reselectHandler);
    clearButton.addEventListener('click', clearSelectionHandler);
    copyButton.addEventListener('click', copyHandler);
    hideButton.addEventListener('click', hideHandler);
    showButton.addEventListener('click', showHandler);
    hoverColorInput.addEventListener('input', updateHoverColor);
    selectionColorInput.addEventListener('input', updateSelectionColor);
    minimizeButton.addEventListener('click', toggleMinimizeHandler);
    shortSelectorCheckbox.addEventListener('change', generateAndDraw);
    
    // Wczytywanie kolorów na starcie
    chrome.runtime.sendMessage({ type: 'getColors' }, (response) => {
        if (response) {
            if (response.hoverColor) {
                hoverColorInput.value = response.hoverColor;
            }
            if (response.selectionColor) {
                selectionColorInput.value = response.selectionColor;
            }
        }
        // Zastosuj kolory (bez ponownego zapisywania)
        const initialHoverColor = hoverColorInput.value;
        hoverHighlightPath.style.setProperty('fill', hexToRgba(initialHoverColor, 0.2), 'important');
        hoverHighlightPath.style.setProperty('stroke', initialHoverColor, 'important');
        hoverHighlightPath.style.setProperty('stroke-width', '1px', 'important');

        const initialSelectionColor = selectionColorInput.value;
        selectionHighlightPath.style.setProperty('fill', hexToRgba(initialSelectionColor, 0.2), 'important');
        selectionHighlightPath.style.setProperty('stroke', initialSelectionColor, 'important');
        selectionHighlightPath.style.setProperty('stroke-width', '1px', 'important');
    });

    filterDisplay.addEventListener('input', () => {
        const finalSelector = filterDisplay.textContent.startsWith('##') ? filterDisplay.textContent.substring(2) : filterDisplay.textContent;
        let selectionPathData = '';
        try { document.querySelectorAll(finalSelector).forEach(el => { if (el.classList.contains('ubo-picker-ignore')) return; const rect = el.getBoundingClientRect(); if (rect.width > 0 || rect.height > 0) { selectionPathData += `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `; } }); } catch (e) {}
        selectionHighlightPath.setAttribute('d', selectionPathData);
    });
})();