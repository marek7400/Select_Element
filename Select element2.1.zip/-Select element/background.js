chrome.action.onClicked.addListener((tab) => {
  // Wstrzyknij style CSS do aktywnej karty
  chrome.scripting.insertCSS({
    target: { tabId: tab.id },
    files: ["picker.css"]
  });

  // Wstrzyknij i wykonaj skrypt contentowy
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["picker.js"]
  });
});

// Nasłuchuj wiadomości od skryptów contentowych
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Sprawdź, czy wiadomość jest typu 'saveFilter'
    if (request.type === 'saveFilter') {
        const newFilter = request.filter;
        if (!newFilter) {
            console.error('Otrzymano pusty filtr do zapisu.');
            return;
        }
        chrome.storage.local.get({ userFilters: [] }, (data) => {
            const filters = data.userFilters;
            if (!filters.includes(newFilter)) {
                filters.push(newFilter);
            }
            chrome.storage.local.set({ userFilters: filters }, () => {
                console.log('Filtr zapisany pomyślnie:', newFilter);
            });
        });
        return; // Zakończ, jeśli to była ta wiadomość
    }
    
    // === ZMIANA: Obsługa zapisywania i odczytywania kolorów ===
    
    if (request.type === 'getColors') {
        chrome.storage.sync.get(['hoverColor', 'selectionColor'], (data) => {
            sendResponse({
                hoverColor: data.hoverColor,
                selectionColor: data.selectionColor
            });
        });
        // Zwróć true, aby wskazać, że odpowiedź zostanie wysłana asynchronicznie
        return true; 
    }
    
    if (request.type === 'saveHoverColor') {
        chrome.storage.sync.set({ hoverColor: request.color });
    }
    
    if (request.type === 'saveSelectionColor') {
        chrome.storage.sync.set({ selectionColor: request.color });
    }
});