// picker.js

// --- Zmienne globalne i listenery ---
const isTopFrame = window === window.top;
const MESSAGE_PREFIX = 'ubo-picker-msg::';
let activeFrames = []; // Używane tylko w top-frame

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'activatePicker') {
    initialize();
  }
});

let currentSelector = '';
let currentMode = 'similar';

window.addEventListener('message', (event) => {
    if (event.source === window || !event.data || typeof event.data.type !== 'string' || !event.data.type.startsWith(MESSAGE_PREFIX)) {
        return;
    }
    const { type, payload } = event.data;

    if (isTopFrame && window.elementPickerInstance) {
        switch (type) {
            case `${MESSAGE_PREFIX}frame-ready`:
                if (!activeFrames.includes(event.source)) activeFrames.push(event.source);
                break;
            case `${MESSAGE_PREFIX}frame-clicked`:
                window.elementPickerInstance.pauseAndTakeControl(payload.path);
                break;
            case `${MESSAGE_PREFIX}frame-quit`:
                window.elementPickerInstance.cleanup();
                break;
        }
    } 
    else if (!isTopFrame && window.elementPickerInstance) {
         switch (type) {
            case `${MESSAGE_PREFIX}pause-all`: window.elementPickerInstance.pause(); break;
            case `${MESSAGE_PREFIX}resume-all`: window.elementPickerInstance.resume(); break;
            case `${MESSAGE_PREFIX}update-selection`: 
                currentSelector = payload.selector;
                currentMode = payload.mode;
                window.elementPickerInstance.drawSelection(payload.selector, payload.mode); 
                break;
            case `${MESSAGE_PREFIX}apply-rule`: 
                window.elementPickerInstance.applyDisplayRule(payload.selector, payload.display); 
                break;
            case `${MESSAGE_PREFIX}shutdown-all`: window.elementPickerInstance.cleanup(); break;
        }
    }
});


function initialize() {
    if (window.elementPickerHasRun) return;
    window.elementPickerHasRun = true;

    let isPaused = false;
    let isDragging = false;
    let isFrozenByJs = false;
    let lastTarget = null;
    let clickedElementRef = null;
    let fullSelectorPath = [];
    let hiddenSelectors = [];
    let scrollThrottleTimer = null;
    let frozenCssItems = []; // Przechowuje { element: li, subMenu: ul/div, overlayDiv, originalStyle }

    const EVENTS_TO_BLOCK = ['mouseout', 'mouseleave', 'blur', 'focusout'];
    
    const eventBlocker = (e) => {
        e.stopPropagation();
    };

    const overlay = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    overlay.id = 'ubo-picker-overlay';
    const hoverHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(hoverHighlightPath);
    const selectionHighlightPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
    overlay.appendChild(selectionHighlightPath);
    document.body.appendChild(overlay);
    
    const hexToRgba = (hex, alpha = 1) => {
        let r = 0, g = 0, b = 0;
        if (hex.length === 4) { r = "0x" + hex[1] + hex[1]; g = "0x" + hex[2] + hex[2]; b = "0x" + hex[3] + hex[3]; } 
        else if (hex.length === 7) { r = "0x" + hex[1] + hex[2]; g = "0x" + hex[3] + hex[4]; b = "0x" + hex[5] + hex[6]; }
        return `rgba(${+r},${+g},${+b},${alpha})`;
    };
    
    const setPathStyles = (path, color) => {
        path.style.setProperty('fill', hexToRgba(color, 0.2), 'important');
        path.style.setProperty('stroke', color, 'important');
        path.style.setProperty('stroke-width', '1px', 'important');
    };
    
    setPathStyles(hoverHighlightPath, '#0064FF');
    setPathStyles(selectionHighlightPath, '#FF0000');
    
    const getSelectorForPart = (part, level) => {
        const tag = part.tag;
        const id = part.id ? `#${CSS.escape(part.id)}` : null;
        const classes = part.classes.filter(c => !c.startsWith('ubo-picker-')).sort().map(c => `.${CSS.escape(c)}`).join('');
        switch (level) {
            case 0: return tag;
            case 1: return id || tag;
            case 2: return classes || tag;
            case 3: default: return id || classes || tag;
        }
    };
    
    const drawSelection = (selector, mode = 'similar') => {
        let selectionPathData = '';
        try {
            if (!selector) {} 
            else if (mode === 'single') {
                const el = document.querySelector(selector);
                if (el) {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 || rect.height > 0) {
                        selectionPathData = `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `;
                    }
                }
            } else {
                const matchedElements = document.querySelectorAll(selector);
                matchedElements.forEach(el => {
                    if (el.classList.contains('ubo-picker-ignore')) return;
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 || rect.height > 0) {
                       selectionPathData += `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z `;
                    }
                });
            }
        } catch (e) { 
            if(isTopFrame) document.getElementById('ubo-picker-hide-button').disabled = true;
        }
        selectionHighlightPath.setAttribute('d', selectionPathData);
    };

    const mouseMoveHandler = (e) => {
        if (isPaused || (isTopFrame && isDragging)) return;
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) {
            hoverHighlightPath.setAttribute('d', '');
            lastTarget = null;
            return;
        }
        if (target === lastTarget) return;
        lastTarget = target;
        const rect = target.getBoundingClientRect();
        hoverHighlightPath.setAttribute('d', `M${rect.left},${rect.top} h${rect.width} v${rect.height} h-${rect.width} z`);
    };
    
    const clickHandler = (e) => {
        const target = e.target;
        if (target.closest('.ubo-picker-ignore')) return;
        e.preventDefault();
        e.stopPropagation();
        clickedElementRef = target;
        const path = [];
        let current = target;
        while (current && current.tagName !== 'HTML') {
            let nth = 1;
            let sibling = current.previousElementSibling;
            while(sibling) {
                if (sibling.tagName === current.tagName) nth++;
                sibling = sibling.previousElementSibling;
            }
            path.unshift({ tag: current.tagName.toLowerCase(), id: current.id, classes: Array.from(current.classList), nth: nth });
            current = current.parentElement;
        }
        if (isTopFrame) {
            pauseAndTakeControl(path);
        } else {
            window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-clicked`, payload: { path } }, '*');
        }
    };
    
    const repositionFrozenOverlays = () => {
        frozenCssItems.forEach(item => {
            const rect = item.element.getBoundingClientRect();
            item.overlayDiv.style.left = `${rect.left + window.scrollX}px`;
            item.overlayDiv.style.top = `${rect.top + window.scrollY}px`;
            item.overlayDiv.style.width = `${rect.width}px`;
            item.overlayDiv.style.height = `${rect.height}px`;
        });
    };

    const keydownHandler = (e) => {
        if (e.key === 'Escape') {
            e.preventDefault(); e.stopPropagation();
            if (isTopFrame) cleanup(); else window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-quit` }, '*');
        }
        if (isTopFrame && e.key.toLowerCase() === 'z' && !e.ctrlKey && !e.altKey && !e.metaKey) {
            e.preventDefault(); e.stopPropagation();
            if (window.elementPickerInstance) window.elementPickerInstance.toggleCssFreeze();
        }
    };
    
    const applyDisplayRule = (selector, displayValue) => {
        if (!selector) return;
        try { document.querySelectorAll(selector).forEach(el => {
            if (displayValue === '') el.style.removeProperty('display');
            else el.style.setProperty('display', displayValue, 'important');
        }); } catch (e) { console.error("Błąd przy stosowaniu reguły widoczności:", selector, e); }
    };

    const throttledRedraw = () => {
        if (scrollThrottleTimer) return;
        scrollThrottleTimer = setTimeout(() => {
            if (isPaused) {
                if (isTopFrame) generateAndDraw();
                else drawSelection(currentSelector, currentMode);
            }
            repositionFrozenOverlays();
            scrollThrottleTimer = null;
        }, 50);
    };

    const cleanup = () => {
        if (!window.elementPickerHasRun) return;

        frozenCssItems.forEach(item => {
            if (item.overlayDiv.parentNode) item.overlayDiv.parentNode.removeChild(item.overlayDiv);
            item.subMenu.style.cssText = item.originalStyle;
        });
        frozenCssItems = [];
        
        if (isFrozenByJs) {
            EVENTS_TO_BLOCK.forEach(eventType => window.removeEventListener(eventType, eventBlocker, true));
            isFrozenByJs = false;
        }

        if (isTopFrame) {
            if (hiddenSelectors.length > 0) {
                hiddenSelectors.forEach(selector => {
                    const selectorToShow = selector.startsWith('##') ? selector.substring(2) : selector;
                    applyDisplayRule(selectorToShow, '');
                    activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' } }, '*'));
                });
            }
            activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}shutdown-all` }, '*'));
            const panel = document.getElementById('ubo-picker-panel');
            if(panel && panel.parentNode) panel.parentNode.removeChild(panel);
        }
        document.body.classList.remove('ubo-picker-active');
        document.removeEventListener('mousemove', mouseMoveHandler, true);
        document.removeEventListener('click', clickHandler, true);
        document.removeEventListener('keydown', keydownHandler, true);
        document.removeEventListener('scroll', throttledRedraw, true);
        window.removeEventListener('resize', throttledRedraw);
        if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
        window.elementPickerHasRun = false;
        window.elementPickerInstance = null;
    };
    
    const pause = () => {
        isPaused = true;
        hoverHighlightPath.setAttribute('d', '');
        document.body.classList.remove('ubo-picker-active');
    };
    
    const resume = () => {
        isPaused = false;
        clickedElementRef = null;
        selectionHighlightPath.setAttribute('d', '');
        document.body.classList.add('ubo-picker-active');
    };

    document.body.classList.add('ubo-picker-active');
    document.addEventListener('mousemove', mouseMoveHandler, true);
    document.addEventListener('click', clickHandler, true);
    document.addEventListener('keydown', keydownHandler, true);
    document.addEventListener('scroll', throttledRedraw, true);
    window.addEventListener('resize', throttledRedraw);

    let panel, filterDisplay, quitButton, moveHandle, pathSlider, pathTicksContainer, selectButton, clearButton, copyButton, hideButton, showButton, undoButton, attrSlider, minimizeButton, hoverColorInput, selectionColorInput, shortSelectorCheckbox, similarCheckbox, freezeButton;
    
    if (isTopFrame) {
        panel = document.createElement('aside');
        panel.id = 'ubo-picker-panel';
        panel.innerHTML = `
            <div id="ubo-picker-window-bar">
                <div id="ubo-picker-move-handle"></div>
                <div id="ubo-picker-controls-container">
                    <input type="color" id="ubo-picker-hover-color-input" class="ubo-picker-color-swatch" title="Zmień kolor wyszukiwania" value="#0064FF">
                    <input type="color" id="ubo-picker-selection-color-input" class="ubo-picker-color-swatch" title="Zmień kolor zaznaczenia" value="#FF0000">
                    <button id="ubo-picker-freeze-button" title="Zamroź dynamiczne elementy (JS lub CSS - klawisz 'z')">❄️</button>
                    <button id="ubo-picker-minimize-button" title="Minimalizuj">_</button>
                    <button id="ubo-picker-quit" title="Zakończ (Esc)">×</button>
                </div>
            </div>
            <div id="ubo-picker-content">
                <div id="ubo-picker-filter-display" contenteditable="true" spellcheck="false"></div>
                <div id="ubo-picker-sliders">
                    <div class="ubo-picker-slider-container"><div class="ubo-picker-slider-wrapper"><input type="range" min="0" max="0" value="0" id="ubo-picker-path-slider" disabled><div id="ubo-picker-path-ticks-container"></div></div></div>
                    <div class="ubo-picker-slider-container"><input type="range" min="0" max="3" value="3" id="ubo-picker-attr-slider" disabled></div>
                </div>
                <div id="ubo-picker-actions">
                    <div class="ubo-picker-checkbox-container">
                        <div class="ubo-picker-checkbox-item"><input type="checkbox" id="ubo-picker-similar-checkbox" disabled checked><label for="ubo-picker-similar-checkbox">Similar</label></div>
                        <div class="ubo-picker-checkbox-item"><input type="checkbox" id="ubo-picker-short-selector-checkbox" disabled><label for="ubo-picker-short-selector-checkbox">Short</label></div>
                    </div>
                    <button id="ubo-picker-select-button" disabled>SELECT</button><button id="ubo-picker-clear-button" disabled>CLEAR</button><button id="ubo-picker-hide-button" disabled>HIDE</button><button id="ubo-picker-undo-button" disabled>UNDO</button><button id="ubo-picker-show-button" disabled>SHOW</button><button id="ubo-picker-copy-button" disabled>COPY</button>
                </div>
            </div>
        `;
        panel.style.width = (window.screen.width / 4) + 'px';
        panel.querySelectorAll('*').forEach(el => el.classList.add('ubo-picker-ignore'));
        panel.classList.add('ubo-picker-ignore');
        document.body.appendChild(panel);

        filterDisplay = document.getElementById('ubo-picker-filter-display'); quitButton = document.getElementById('ubo-picker-quit'); moveHandle = document.getElementById('ubo-picker-move-handle'); pathSlider = document.getElementById('ubo-picker-path-slider'); pathTicksContainer = document.getElementById('ubo-picker-path-ticks-container'); selectButton = document.getElementById('ubo-picker-select-button'); clearButton = document.getElementById('ubo-picker-clear-button'); copyButton = document.getElementById('ubo-picker-copy-button'); hideButton = document.getElementById('ubo-picker-hide-button'); showButton = document.getElementById('ubo-picker-show-button'); undoButton = document.getElementById('ubo-picker-undo-button'); attrSlider = document.getElementById('ubo-picker-attr-slider'); minimizeButton = document.getElementById('ubo-picker-minimize-button'); hoverColorInput = document.getElementById('ubo-picker-hover-color-input'); selectionColorInput = document.getElementById('ubo-picker-selection-color-input'); shortSelectorCheckbox = document.getElementById('ubo-picker-short-selector-checkbox'); similarCheckbox = document.getElementById('ubo-picker-similar-checkbox'); freezeButton = document.getElementById('ubo-picker-freeze-button');
    }
    
    const generateAndDraw = () => { if (!isPaused || fullSelectorPath.length === 0) return; const isSimilarMode = similarCheckbox.checked; let finalSelector = ''; let modeForDrawing = 'similar'; if (isSimilarMode) { modeForDrawing = 'similar'; pathSlider.disabled = false; attrSlider.disabled = false; shortSelectorCheckbox.disabled = false; attrSlider.max = 3; pathSlider.max = fullSelectorPath.length > 0 ? fullSelectorPath.length - 1 : 0; const pathIndex = parseInt(pathSlider.value, 10); const attrLevel = parseInt(attrSlider.value, 10); const isShortMode = shortSelectorCheckbox.checked; const currentPath = fullSelectorPath.slice(0, fullSelectorPath.length - pathIndex); if (isShortMode) { const lastElementInPath = currentPath[currentPath.length - 1]; if (lastElementInPath) finalSelector = getSelectorForPart(lastElementInPath, attrLevel); } else { finalSelector = currentPath.map(part => getSelectorForPart(part, attrLevel)).join(' > '); } } else { modeForDrawing = 'single'; pathSlider.disabled = false; attrSlider.disabled = false; shortSelectorCheckbox.disabled = true; pathSlider.max = fullSelectorPath.length - 1; const levelIndex = parseInt(pathSlider.value, 10); const targetPartIndex = fullSelectorPath.length - 1 - levelIndex; const targetPart = fullSelectorPath[targetPartIndex]; const getPartSelector = (part) => part.id ? `#${CSS.escape(part.id)}` : `${part.tag}:nth-of-type(${part.nth})`; const getParentSelector = (endIndex) => fullSelectorPath.slice(0, endIndex).map(getPartSelector).join(' > '); const parentSelector = getParentSelector(targetPartIndex); const parentOfTarget = parentSelector ? document.querySelector(parentSelector) : document.body; let siblingsCount = 0; if (parentOfTarget && targetPart) { siblingsCount = Array.from(parentOfTarget.children).filter(child => child.tagName.toLowerCase() === targetPart.tag).length; } attrSlider.max = Math.max(0, siblingsCount - 1); const currentNth = parseInt(attrSlider.value, 10) + 1; const modifiedTargetPart = { ...targetPart, nth: currentNth }; const selectorParts = fullSelectorPath.slice(0, targetPartIndex).map(getPartSelector); selectorParts.push(getPartSelector(modifiedTargetPart)); finalSelector = selectorParts.join(' > '); } pathTicksContainer.innerHTML = ''; if (pathSlider.max >= 0 && !pathSlider.disabled) { for (let i = 0; i <= pathSlider.max; i++) { const tick = document.createElement('div'); tick.className = 'tick'; pathTicksContainer.appendChild(tick); } } if (filterDisplay.textContent !== `##${finalSelector}`) filterDisplay.textContent = `##${finalSelector}`; currentSelector = finalSelector; currentMode = modeForDrawing; drawSelection(finalSelector, modeForDrawing); activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: finalSelector, mode: modeForDrawing } }, '*')); };
    const pauseAndTakeControl = (path) => { fullSelectorPath = path; pause(); activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}pause-all` }, '*')); selectButton.disabled = false; clearButton.disabled = false; copyButton.disabled = false; similarCheckbox.disabled = false; hideButton.disabled = false;  if (similarCheckbox.checked) { pathSlider.value = 0; attrSlider.value = 3; } else { const lastPart = path.length > 0 ? path[path.length - 1] : { nth: 1 }; pathSlider.value = 0; attrSlider.value = Math.max(0, lastPart.nth - 1); } generateAndDraw(); };

    if (isTopFrame) {
        const clearCssFreeze = () => {
            frozenCssItems.forEach(item => {
                if (item.overlayDiv.parentNode) item.overlayDiv.parentNode.removeChild(item.overlayDiv);
                item.subMenu.style.cssText = item.originalStyle;
            });
            frozenCssItems = [];
            if (!isFrozenByJs) freezeButton.classList.remove('active');
        };
        
        const clearJsFreeze = () => {
            if (isFrozenByJs) {
                isFrozenByJs = false;
                EVENTS_TO_BLOCK.forEach(eventType => window.removeEventListener(eventType, eventBlocker, true));
                if (frozenCssItems.length === 0) freezeButton.classList.remove('active');
            }
        };

        const toggleJsFreeze = () => {
            clearCssFreeze();
            isFrozenByJs = !isFrozenByJs;
            if (isFrozenByJs) {
                freezeButton.classList.add('active');
                EVENTS_TO_BLOCK.forEach(eventType => window.addEventListener(eventType, eventBlocker, true));
            } else {
                clearJsFreeze();
            }
        };

        const toggleCssFreeze = () => {
            clearJsFreeze();
            if (!lastTarget) return;
            const targetLi = lastTarget.closest('li');
            if (!targetLi) return;

            const itemIndex = frozenCssItems.findIndex(item => item.element === targetLi);

            if (itemIndex > -1) {
                const item = frozenCssItems[itemIndex];
                if (item.overlayDiv.parentNode) item.overlayDiv.parentNode.removeChild(item.overlayDiv);
                item.subMenu.style.cssText = item.originalStyle;
                frozenCssItems.splice(itemIndex, 1);
            } else {
                const subMenu = targetLi.querySelector('ul, div');
                if (!subMenu) return;

                const originalStyle = subMenu.style.cssText;
                
                // The menu is visible due to user hover, so we can get its computed style directly.
                const computed = window.getComputedStyle(subMenu);
                
                // We copy all relevant layout and visibility properties to "freeze" the element's state.
                const styleToApply = `display: ${computed.display}; visibility: ${computed.visibility}; opacity: ${computed.opacity}; position: ${computed.position}; top: ${computed.top}; left: ${computed.left}; width: ${computed.width}; height: ${computed.height}; transform: ${computed.transform}; z-index: ${computed.zIndex};`;
                subMenu.style.cssText = originalStyle + styleToApply;

                const overlayDiv = document.createElement('div');
                overlayDiv.className = 'ubo-picker-frozen-overlay';
                document.body.appendChild(overlayDiv);
                frozenCssItems.push({ element: targetLi, subMenu: subMenu, overlayDiv: overlayDiv, originalStyle: originalStyle });
            }
            
            if (frozenCssItems.length > 0) {
                freezeButton.classList.add('active');
            } else {
                freezeButton.classList.remove('active');
            }
            repositionFrozenOverlays();
        };

        const copyHandler = () => { const filterText = filterDisplay.textContent; if (filterText) { chrome.runtime.sendMessage({ type: 'saveFilter', filter: filterText }); navigator.clipboard.writeText(filterText).then(() => { copyButton.textContent = 'COPIED!'; setTimeout(() => { copyButton.textContent = 'COPY'; }, 1000); }); } };
        const clearSelectionHandler = () => { fullSelectorPath = []; clickedElementRef = null; currentSelector = ''; drawSelection(''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: '', mode: 'similar' }}, '*')); filterDisplay.textContent = ''; pathTicksContainer.innerHTML = ''; pathSlider.disabled = true; pathSlider.value = 0; attrSlider.disabled = true; clearButton.disabled = true; copyButton.disabled = true; hideButton.disabled = true; shortSelectorCheckbox.disabled = true; similarCheckbox.disabled = true; };
        const reselectHandler = () => { clearSelectionHandler(); resume(); activeFrames.forEach(frame => frame.postMessage({ type: `${MESSAGE_PREFIX}resume-all` }, '*')); selectButton.disabled = true; };
        const hideHandler = () => { const selectorToHide = filterDisplay.textContent.trim(); if (!selectorToHide) return; if (!hiddenSelectors.includes(selectorToHide)) hiddenSelectors.push(selectorToHide); const cleanSelector = selectorToHide.startsWith('##') ? selectorToHide.substring(2) : selectorToHide; applyDisplayRule(cleanSelector, 'none'); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: cleanSelector, display: 'none' }}, '*')); drawSelection(''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}update-selection`, payload: { selector: '', mode: 'similar' }}, '*')); showButton.disabled = false; undoButton.disabled = false; };
        const undoHandler = () => { if (hiddenSelectors.length === 0) return; const selectorToUndo = hiddenSelectors.pop(); const selectorToShow = selectorToUndo.startsWith('##') ? selectorToUndo.substring(2) : selectorToUndo; applyDisplayRule(selectorToShow, ''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' }}, '*')); if (hiddenSelectors.length === 0) { showButton.disabled = true; undoButton.disabled = true; } generateAndDraw(); };
        const showHandler = () => { if (hiddenSelectors.length === 0) return; hiddenSelectors.forEach(selector => { const selectorToShow = selector.startsWith('##') ? selector.substring(2) : selector; applyDisplayRule(selectorToShow, ''); activeFrames.forEach(frame => frame.postMessage({type: `${MESSAGE_PREFIX}apply-rule`, payload: { selector: selectorToShow, display: '' }}, '*')); }); hiddenSelectors = []; showButton.disabled = true; undoButton.disabled = true; generateAndDraw(); };
        const toggleMinimizeHandler = () => { panel.classList.toggle('ubo-picker-minimized'); };
        let pos1=0, pos2=0, pos3=0, pos4=0; function dragMouseDown(e) { e = e || window.event; e.preventDefault(); const rect = panel.getBoundingClientRect(); panel.style.top = rect.top + 'px'; panel.style.left = rect.left + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto'; pos3 = e.clientX; pos4 = e.clientY; document.onmouseup = closeDragElement; document.onmousemove = elementDrag; isDragging = true; } function elementDrag(e) { e = e || window.event; e.preventDefault(); pos1 = pos3 - e.clientX; pos2 = pos4 - e.clientY; pos3 = e.clientX; pos4 = e.clientY; panel.style.top = (panel.offsetTop - pos2) + "px"; panel.style.left = (panel.offsetLeft - pos1) + "px"; } function closeDragElement() { document.onmouseup = null; document.onmousemove = null; isDragging = false; }

        quitButton.addEventListener('click', cleanup); moveHandle.addEventListener('mousedown', dragMouseDown); pathSlider.addEventListener('input', generateAndDraw); attrSlider.addEventListener('input', generateAndDraw); selectButton.addEventListener('click', reselectHandler); clearButton.addEventListener('click', clearSelectionHandler); copyButton.addEventListener('click', copyHandler); hideButton.addEventListener('click', hideHandler); undoButton.addEventListener('click', undoHandler); showButton.addEventListener('click', showHandler); minimizeButton.addEventListener('click', toggleMinimizeHandler); freezeButton.addEventListener('click', toggleJsFreeze); shortSelectorCheckbox.addEventListener('change', generateAndDraw);
        similarCheckbox.addEventListener('change', () => { if (fullSelectorPath.length > 0) pauseAndTakeControl(fullSelectorPath); });
        filterDisplay.addEventListener('input', generateAndDraw);
        hoverColorInput.addEventListener('input', () => { const newColor = hoverColorInput.value; setPathStyles(hoverHighlightPath, newColor); chrome.runtime.sendMessage({ type: 'saveHoverColor', color: newColor }); });
        selectionColorInput.addEventListener('input', () => { const newColor = selectionColorInput.value; setPathStyles(selectionHighlightPath, newColor); chrome.runtime.sendMessage({ type: 'saveSelectionColor', color: newColor }); });
        chrome.runtime.sendMessage({ type: 'getColors' }, (response) => { if (response) { if (response.hoverColor) { hoverColorInput.value = response.hoverColor; setPathStyles(hoverHighlightPath, response.hoverColor); } if (response.selectionColor) { selectionColorInput.value = response.selectionColor; setPathStyles(selectionHighlightPath, response.selectionColor); } } });

        window.elementPickerInstance = { cleanup, pause, resume, drawSelection, applyDisplayRule, pauseAndTakeControl, toggleCssFreeze };
    } else {
        window.elementPickerInstance = { cleanup, pause, resume, drawSelection, applyDisplayRule };
    }

    if (!isTopFrame) window.top.postMessage({ type: `${MESSAGE_PREFIX}frame-ready` }, '*');
}